#!/bin/bash

# Parte 1: suma
X=$1
C=$(netstat | grep "ESTABLISHED" | wc -l)
sum=$(($X + $C))
echo "X = ${X}, C = ${C}, suma = ${sum}"

# Parte 2: archivo
mkdir /tmp/Ej1
while IFS= read -r line
do
	echo $sum > "/tmp/Ej1/${line}.txt"
done < /home/urtea2014/people.txt
