#!/bin/bash

stress-ng -c 1 -t 5

name="Gaizka"
time=$(date)
msg="Stress realizado por ${name} a las ${time}."
mosquitto_pub -h 35.195.64.55 -t examen -m ${msg} -r -q 1
echo "Enviado"
logger -p user.info "Stress realizado"
